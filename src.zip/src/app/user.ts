export interface User {
  name:string,
  uid:string,
  pwd:string,
  cpwd:string,
  dob:string,
  gender:string,
  country:string,
  address:string,
  pincode:string,
  contact:string,
  email:string
}